﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CompanyCoreLib
{
    class DateTimeWithCourier
    {
        public DateTime DateTimeProp;
        public int Courier;
    }
    public class Analytics
    {
        public List<DateTime> PopularMonths(List<DateTime> dates)
        {
            var DateTimeWithCourierList = new List<DateTimeWithCourier>();

            foreach (DateTime date in dates)
            {
                var DateMonthStart = new DateTime(date.Year, date.Month, 1, 0, 0, 0);

                var index = DateTimeWithCourierList.FindIndex(item => item.DateTimeProp == DateMonthStart);

                if (index == -1)
                {
                    DateTimeWithCourierList.Add(new DateTimeWithCourier
                    {
                        DateTimeProp = DateMonthStart,
                        Courier = 1
                    });
                }
                else
                {
                    DateTimeWithCourierList[index].Courier++;
                }
            }
            return DateTimeWithCourierList.OrderByDescending(item => item.Courier)
                .ThenBy(item => item.DateTimeProp)
                .Select(item => item.DateTimeProp)
                .ToList();
        }
    }
}
